<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="index.html">Project Cepat</a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="index.html">RB</a>
        </div>
        <ul class="sidebar-menu">

            <li class="nav-item dropdown">
                <a href="#" class="nav-link has-dropdown"><i class="fas fa-fire"></i><span>Management
                        Sales</span></a>
                <ul class="dropdown-menu">
                    <li class=''>
                        <a class="nav-link" href="{{ route('stock.index') }}">Users</a>
                    </li>
                    <li class=''>
                        <a class="nav-link" href="{{ route('dataOtlet.index') }}">Outlets</a>
                    </li>
                    <li class=''>
                        <a class="nav-link" href="{{ route('toko.index') }}">Outlets</a>
                    </li>
                </ul>
            </li>
</div>
