<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Laravel Leaflet Maps</title>
    <style>
        body {
            margin: 0;
            font-family: Arial, sans-serif;
        }

        #container {
            display: flex;
        }

        #details {
            width: 300px;
            padding: 10px;
            background-color: #f4f4f4;
            border-right: 2px solid #ccc;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
        }

        #map {
            flex: 1;
            height: 100vh;
        }

        .accordion {
            background-color: #eee;
            border: 1px solid #ccc;
            border-radius: 5px;
            margin-bottom: 5px;
            cursor: pointer;
            padding: 10px;
            text-align: left;
            font-weight: bold;
        }

        .accordion:hover {
            background-color: #ddd;
        }

        .panel {
            display: none;
            overflow: hidden;
            padding: 10px;
            background-color: white;
            border: 1px solid #ccc;
            border-top: none;
        }

        .visit-order {
            font-size: 20px;
            font-weight: bold;
            color: red;
            text-align: center;
            padding: 0px;
            position: absolute;
            top: 0px;
            /* Adjust based on your icon size */
            left: 100%;
            transform: translateX(-50%);
            background-color: white;
            border-radius: 100%;
            /* Make the background circular */
            width: 30px;
            /* Adjust width to make it circular */
            height: 30px;
            /* Adjust height to match width */
            line-height: 30px;
            /* Center the text vertically */
            z-index: 1000;
            text-shadow:
                -1px -1px 0 #000,
                1px -1px 0 #000,
                -1px 1px 0 #000,
                1px 1px 0 #000;
            /* Black shadow creates a border effect */
        }



        .custom-icon {
            position: relative;
        }
    </style>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
</head>

<body>
    <div id="container">
        <div id="details"></div>
        <div id="map"></div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <script>
        // Initialize the map with the desired view and zoom level
        var map = L.map('map').setView([-8.609471, 116.135256], 13);

        // Use OpenStreetMap tile layer
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 20
        }).addTo(map);

        // Function to format duration in hours and minutes
        function formatDuration(start, end) {
            var startTime = new Date(start);
            var endTime = new Date(end);
            var duration = Math.floor((endTime - startTime) / 60000); // Duration in minutes
            var hours = Math.floor(duration / 60);
            var minutes = duration % 60;
            return hours + 'h ' + minutes + 'm';
        }

        // Function to calculate distance between two lat/lng points in meters
        function calculateDistance(lat1, lon1, lat2, lon2) {
            var R = 6371000; // Radius of the Earth in meters
            var dLat = (lat2 - lat1) * Math.PI / 180;
            var dLon = (lon2 - lon1) * Math.PI / 180;
            var a =
                0.5 - Math.cos(dLat) / 2 +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                (1 - Math.cos(dLon)) / 2;
            return R * 2 * Math.asin(Math.sqrt(a));
        }

        // Function to add markers from the database check-ins and draw lines
        function addMarkersAndLines(checkins, tokos) {
            var latlngs = [];
            var detailsHtml = '';

            checkins.forEach(function(checkin, index) {
                // Extract the check-in and check-out times
                var checkInTime = new Date(checkin.first_checkin).toLocaleTimeString();
                var checkOutTime = new Date(checkin.last_checkout).toLocaleTimeString();
                var duration = formatDuration(checkin.first_checkin, checkin.last_checkout);

                // Find the nearest toko
                var nearestToko = null;
                var minDistance = Infinity;

                tokos.forEach(function(toko) {
                    var distance = calculateDistance(checkin.latitude, checkin.longitude, toko.latitude,
                        toko.longitude);
                    if (distance < minDistance) {
                        minDistance = distance;
                        nearestToko = toko;
                    }
                });

                // Determine marker color and status based on distance
                var markerColor = (minDistance <= 10) ? 'biru' : 'merah';
                var status = (markerColor === 'biru') ? 'Berhasil Check-in' : 'Gagal Check-in';

                // Create a custom icon with visitOrder
                var customIcon = L.divIcon({
                    className: 'custom-icon',
                    html: `
                    <div class="visit-order">${index + 1}</div>
                    <img src="/img/map${markerColor}.png" width="60" height="60" />
                `,
                    iconSize: [30, 30], // Adjust size based on your icon
                    iconAnchor: [15, 30] // Center the icon
                });

                // Create a marker with the custom icon
                var marker = L.marker([checkin.latitude, checkin.longitude], {
                    icon: customIcon
                }).addTo(map);

                // Add the marker position to the latlngs array
                latlngs.push([checkin.latitude, checkin.longitude]);

                // If check-in failed, add a marker for the nearest toko
                if (markerColor === 'red' && nearestToko) {
                    var tokoMarker = L.marker([nearestToko.latitude, nearestToko.longitude], {
                        icon: redIcon
                    }).addTo(map);

                    // Bind a popup to show toko name and area when hovered
                    tokoMarker.bindPopup(`<b>${nearestToko.name}</b><br>${nearestToko.area}`).openPopup();

                    // Show popup on mouse over and hide on mouse out
                    tokoMarker.on('mouseover', function() {
                        this.openPopup();
                    });

                    tokoMarker.on('mouseout', function() {
                        this.closePopup();
                    });
                }

                // Build the details HTML for accordion
                detailsHtml += `
                <div class="accordion">Kunjungan ${index + 1}</div>
                <div class="panel">
                    <b>Outlet:</b> ${checkin.outlet_name}<br>
                    <b>Jam Check-in:</b> ${checkInTime}<br>
                    <b>Jam Check-out:</b> ${checkOutTime}<br>
                    <b>Durasi:</b> ${duration}<br>
                    <b>Status:</b> ${status}<br>
                    <b>Jumlah Transaksi:</b> ${checkin.total_orders}<br>
                    <b>Jumlah Tagihan:</b> Rp${(checkin.total_billing || 0).toLocaleString()}
                </div>
            `;
            });

            // Create a polyline connecting all the markers
            if (latlngs.length > 1) {
                L.polyline(latlngs, {
                    color: 'blue'
                }).addTo(map);
            }

            // Update the details section
            $('#details').html(detailsHtml);

            // Attach click event to accordion
            var acc = document.getElementsByClassName("accordion");
            for (var i = 0; i < acc.length; i++) {
                acc[i].addEventListener("click", function() {
                    this.classList.toggle("active");
                    var panel = this.nextElementSibling;
                    if (panel.style.display === "block") {
                        panel.style.display = "none";
                    } else {
                        panel.style.display = "block";
                    }
                });
            }
        }


        // Define red icon for toko markers
        var redIcon = L.icon({
            iconUrl: '/img/departmentstore.png',
            iconSize: [25, 41],
            iconAnchor: [12, 41],
            popupAnchor: [1, -34],
            shadowSize: [41, 41]
        });

        // Function to add toko markers
        function addTokoMarkers(tokos) {
            tokos.forEach(function(toko) {
                // Create a marker for each toko
                var marker = L.marker([toko.latitude, toko.longitude], {
                    icon: redIcon
                }).addTo(map);

                // Add event listeners to show and hide the popup
                marker.on('mouseover', function() {
                    marker.openPopup();
                });

                marker.on('mouseout', function() {
                    marker.closePopup();
                });
            });
        }

        // Retrieve the check-ins and toko data from the backend
        var checkins = @json($checkins);
        var tokos = @json($tokos);

        // Wait for the document to be fully loaded before adding markers and lines
        $(document).ready(function() {
            addMarkersAndLines(checkins, tokos);
            addTokoMarkers(tokos);
        });
    </script>
</body>

</html>
