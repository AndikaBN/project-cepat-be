  <div class="simple-footer">
      Copyright &copy; Stisla 2018
  </div>
