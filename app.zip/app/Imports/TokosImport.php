<?php

namespace App\Imports;

use App\Models\Toko;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;

class TokosImport implements ToModel, WithHeadingRow
{
    public function headingRow(): int
    {
        return 1; // Pastikan ini adalah baris yang tepat
    }

    public function model(array $row)
    {

        // Pastikan semua kunci yang dibutuhkan ada di $row sebelum melanjutkan
        if (!isset($row['name'], $row['latitude'], $row['longitude'], $row['village'])) {
            return null;  // Skip baris jika ada kunci yang hilang
        }
        return new Toko([
            'nama_toko' => $row['name'],  // Sesuaikan dengan header Excel
            'latitude'  => $row['latitude'],
            'longitude' => $row['longitude'],
            'area'      => $row['village'],
        ]);
    }
}
